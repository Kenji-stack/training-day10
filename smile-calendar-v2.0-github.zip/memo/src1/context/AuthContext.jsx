// src/context/AuthContext.jsx
import React, { createContext, useContext, useState, useEffect } from "react";
import { auth } from "../firebase";
import { onAuthStateChanged } from "firebase/auth";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // 🔍 ログイン状態を監視
  useEffect(() => {
    console.log("AuthContext: onAuthStateChanged START");

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      console.log("AuthContext: onAuthStateChanged USER =", user);
      setCurrentUser(user);
      setLoading(false);
    });

    return () => {
      console.log("AuthContext: cleanup");
      unsubscribe();
    };
  }, []);

  // 🔑 Firebase IDトークンを取得
  const getIdToken = async () => {
    if (!auth.currentUser) return null;
    return await auth.currentUser.getIdToken();
  };

  const value = {
    currentUser,
    getIdToken,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
