import React, { useEffect, useState } from "react";
import { getReservations } from "../api/reservationApi";

function ReservationList() {
  const [reservations, setReservations] = useState([]);

  useEffect(() => {
    const load = async () => {
      const data = await getReservations();
      setReservations(data);
    };
    load();
  }, []);

  return (
    <div>
      <h2>予約一覧</h2>

      {reservations.length === 0 ? (
        <p>予約はありません。</p>
      ) : (
        <ul>
          {reservations.map((r) => (
            <li key={r.id}>
              {r.title}（{r.date}）
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ReservationList;
