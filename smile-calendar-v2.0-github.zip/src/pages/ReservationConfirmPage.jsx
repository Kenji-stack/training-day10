// src/pages/ReservationConfirmPage.jsx
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { updateRecord } from "../firebase/reservationApi";

const ReservationConfirmPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const reservation = location.state?.reservation;

  if (!reservation) {
    return <p>予約データがありません。</p>;
  }

  const handleConfirm = async () => {
    console.log("保存ボタンがクリックされました");
    console.log("reservation:", reservation);

    const date = reservation.date;
    const data = {
      title: reservation.title,
      memo: reservation.memo,
    };

    console.log("保存するデータ:", { date, data });

    try {
      console.log("updateRecord を呼び出します...");
      await updateRecord(date, data);
      console.log("updateRecord が成功しました");
    } catch (error) {
      console.error("予約保存エラー:", error);
      alert("保存に失敗しました。");
      return; // エラー時は遷移しない
    }

    // 成功時は必ず遷移
    console.log("完了ページに遷移します");
    navigate("/reserve/complete", { state: reservation });
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">予約確認</h2>

      <div className="space-y-4 mb-6">
        <div className="border-b pb-2">
          <p className="text-sm text-gray-500">日付</p>
          <p className="text-lg font-medium text-gray-900">{reservation.date}</p>
        </div>
        <div className="border-b pb-2">
          <p className="text-sm text-gray-500">タイトル</p>
          <p className="text-lg font-medium text-gray-900">{reservation.title || "(未入力)"}</p>
        </div>
        <div className="border-b pb-2">
          <p className="text-sm text-gray-500">メモ</p>
          <p className="text-lg font-medium text-gray-900 whitespace-pre-wrap">{reservation.memo || "(未入力)"}</p>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={() => navigate(-1)}
          className="flex-1 bg-gray-200 text-gray-700 font-bold py-2 px-4 rounded hover:bg-gray-300 transition duration-200"
        >
          戻る
        </button>
        <button
          onClick={handleConfirm}
          className="flex-1 bg-blue-600 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition duration-200"
        >
          保存する
        </button>
      </div>
    </div>
  );
};

export default ReservationConfirmPage;
