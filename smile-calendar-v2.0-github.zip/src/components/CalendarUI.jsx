import React from 'react'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import { formatDateKey } from '../utils/formatDate'

export default function CalendarUI({ onSelectDate, recordsByDate }) {
  console.log("CalendarUI レンダリング:", { count: recordsByDate ? Object.keys(recordsByDate).length : 0 });

  return (
    <div>
      <Calendar
        onClickDay={(d) => onSelectDate(formatDateKey(d))}
        tileContent={({ date }) => {
          const key = formatDateKey(date)
          const record = recordsByDate && recordsByDate[key]
          if (!record) return null

          const icons = []
          if (record.brushingMorning || record.brushingNoon || record.brushingNight || record.mouthwash || record.floss) icons.push('✨')
          if (record.memo) icons.push('📝')
          if (record.memo && /通院|医院|歯科|予約/.test(record.memo)) icons.push('🏥')

          return (
            <div style={{
              marginTop: '2px',
              fontSize: '16px',
              display: 'flex',
              justifyContent: 'center',
              gap: '2px'
            }}>
              {icons.map((ic, i) => (
                <span
                  key={i}
                  style={{
                    display: 'inline-block',
                    padding: '1px 2px',
                    backgroundColor: 'rgba(255, 255, 255, 0.8)',
                    borderRadius: '3px'
                  }}
                >
                  {ic}
                </span>
              ))}
            </div>
          )
        }}
      />
    </div>
  )
}
