import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebase";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import "../styles/login.css";

export default function Login() {
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setError("");
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      navigate("/");
    } catch (e) {
      console.error("Google login failed", e);
      setError("ログインに失敗しました。再度お試しください。");
    }
  };

  return (
    <div className="apple-login-page">
      <div className="apple-login-card" role="main" aria-labelledby="login-title">
        <h1 id="login-title" className="apple-title">Smile Calendar</h1>
        <p className="apple-sub">予約と通院記録をカンタン管理</p>

        <div className="apple-login-actions">
          <button className="apple-btn apple-btn-google" onClick={handleGoogleLogin}>
            <span>Sign in with Google</span>
          </button>
        </div>

        {error && <div className="apple-error">{error}</div>}

        <footer className="apple-footer">
          <small>By signing in you agree to the Terms of Service.</small>
        </footer>
      </div>
    </div>
  );
}
