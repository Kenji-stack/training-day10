import React, { useEffect, useState } from 'react'
import CalendarUI from './CalendarUI'
import DayRecord from './DayRecord'
import { db, auth } from '../firebase'
import { collection, query, where, onSnapshot } from 'firebase/firestore'
import { formatDateKey } from '../utils/formatDate'
import { useNavigate } from "react-router-dom";

export default function CalendarPage() {
  const [selectedDate, setSelectedDate] = useState(formatDateKey(new Date()))
  const [recordsByDate, setRecordsByDate] = useState({})
  const navigate = useNavigate();

  // 🔥 ログアウト機能追加
  const handleLogout = async () => {
    await auth.signOut();
    navigate("/login");
  };

  useEffect(() => {
    if (!auth.currentUser) return;

    console.log("onSnapshotリスナーを設定:", auth.currentUser.uid)

    const q = query(
      collection(db, 'oralCareRecords'),
      where('uid', '==', auth.currentUser.uid)
    );

    const unsub = onSnapshot(q, (snap) => {
      const map = {};
      snap.docs.forEach(doc => {
        map[doc.id] = doc.data();
      });

      console.log("onSnapshot更新:", { count: snap.docs.length, dates: Object.keys(map) })
      setRecordsByDate(map);
    });

    return () => unsub();
  }, []);

  const todaysRecord = recordsByDate[selectedDate] || null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-end">
            <button
              onClick={handleLogout}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-medium transition duration-200"
            >
              ログアウト
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar Section */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center space-x-2">
                <span>📆</span>
                <span>カレンダー</span>
              </h2>
              <CalendarUI onSelectDate={setSelectedDate} recordsByDate={recordsByDate} />
            </div>
          </div>

          {/* Day Record Section */}
          <div className="lg:col-span-1">
            <DayRecord dateKey={selectedDate} record={todaysRecord} />
          </div>
        </div>
      </main>
    </div>
  );
}
