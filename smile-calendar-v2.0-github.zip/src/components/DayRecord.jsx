// src/components/DayRecord.jsx
import React, { useEffect, useState } from 'react'
import { doc, setDoc, deleteDoc } from "firebase/firestore"
import { db } from "../firebase"
import { useAuth } from "../context/AuthContext"

export default function DayRecord({ dateKey, record }) {
  const { currentUser } = useAuth()

  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)

  // Firestore の record を UI に反映（初回マウント時のみ）
  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
  }, [dateKey, record]);

  // 🔥 安全策: データ更新を検知したら強制的にloadingを解除
  useEffect(() => {
    if (loading) {
      console.log("データ更新を検知: loadingを解除します")
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [record])

  // ------------------------
  // 🔥 Firestore へ保存
  // ------------------------
  const save = async () => {
    if (!currentUser) return alert("ログインが必要です")
    if (!window.confirm("この内容で保存しますか？")) return

    console.log("保存処理開始 - loading:", loading)
    setLoading(true)

    try {
      const ref = doc(db, "oralCareRecords", dateKey)

      console.log("保存開始:", { dateKey, uid: currentUser.uid, form })

      await setDoc(ref, {
        ...form,
        uid: currentUser.uid,
        updatedAt: new Date()
      })

      console.log("保存完了:", dateKey)
      // alert("保存しました") // アラート削除
    } catch (err) {
      console.error("保存エラー:", err)
      // alert("保存に失敗しました") // アラート削除
    } finally {
      setLoading(false)
      console.log("保存処理終了 - loading:", false)
    }
  }

  // ------------------------
  // 🔥 Firestore の削除
  // ------------------------
  const remove = async () => {
    if (!currentUser) return alert("ログインが必要です")
    if (!window.confirm("本当に削除しますか？")) return

    setLoading(true)

    try {
      const ref = doc(db, "oralCareRecords", dateKey)

      console.log("削除開始:", dateKey)
      await deleteDoc(ref)
      console.log("削除完了:", dateKey)

      // alert("削除しました") // アラート削除
    } catch (err) {
      console.error("削除エラー:", err)
      // alert("削除に失敗しました") // アラート削除
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center space-x-2">
        <span>📝</span>
        <span>{dateKey}</span>
      </h2>

      <div className="space-y-3">
        {/* 朝 */}
        <label className="flex items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition duration-150">
          <input
            type="checkbox"
            className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2"
            checked={form.brushingMorning}
            onChange={(e) =>
              setForm({ ...form, brushingMorning: e.target.checked })
            }
          />
          <span className="ml-3 text-gray-700 flex items-center space-x-2">
            <span>🌅</span>
            <span>朝の歯みがき</span>
          </span>
        </label>

        {/* 昼 */}
        <label className="flex items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition duration-150">
          <input
            type="checkbox"
            className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2"
            checked={form.brushingNoon}
            onChange={(e) =>
              setForm({ ...form, brushingNoon: e.target.checked })
            }
          />
          <span className="ml-3 text-gray-700 flex items-center space-x-2">
            <span>☀️</span>
            <span>昼の歯みがき</span>
          </span>
        </label>

        {/* 夜 */}
        <label className="flex items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition duration-150">
          <input
            type="checkbox"
            className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2"
            checked={form.brushingNight}
            onChange={(e) =>
              setForm({ ...form, brushingNight: e.target.checked })
            }
          />
          <span className="ml-3 text-gray-700 flex items-center space-x-2">
            <span>🌙</span>
            <span>夜の歯みがき</span>
          </span>
        </label>

        {/* マウスウォッシュ */}
        <label className="flex items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition duration-150">
          <input
            type="checkbox"
            className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2"
            checked={form.mouthwash}
            onChange={(e) =>
              setForm({ ...form, mouthwash: e.target.checked })
            }
          />
          <span className="ml-3 text-gray-700 flex items-center space-x-2">
            <span>💧</span>
            <span>マウスウォッシュ</span>
          </span>
        </label>

        {/* フロス */}
        <label className="flex items-center p-3 hover:bg-gray-50 rounded-lg cursor-pointer transition duration-150">
          <input
            type="checkbox"
            className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500 focus:ring-2"
            checked={form.floss}
            onChange={(e) =>
              setForm({ ...form, floss: e.target.checked })
            }
          />
          <span className="ml-3 text-gray-700 flex items-center space-x-2">
            <span>🦷</span>
            <span>フロス</span>
          </span>
        </label>

        {/* メモ */}
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            メモ
          </label>
          <textarea
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            rows={4}
            value={form.memo}
            onChange={(e) =>
              setForm({ ...form, memo: e.target.value })
            }
            placeholder="通院予約・通院記録・メモ"
          />
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <button
          onClick={save}
          disabled={loading}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition duration-200"
        >
          {loading ? "保存中..." : "保存"}
        </button>

        <button
          onClick={remove}
          disabled={loading}
          className="flex-1 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition duration-200"
        >
          削除
        </button>
      </div>
    </div>
  )
}
