import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ReservationFormPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    date: "",
    title: "",
    memo: "",
  });

  const submit = () => {
    navigate("/reserve/confirm", { state: { reservation: form } });
  };

  return (
    <div>
      <h2>予約登録</h2>

      <input
        id="date"
        name="date"
        type="date"
        value={form.date}
        onChange={(e) => setForm({ ...form, date: e.target.value })}
      />

      <input
        id="title"
        name="title"
        type="text"
        placeholder="タイトル"
        value={form.title}
        onChange={(e) => setForm({ ...form, title: e.target.value })}
      />

      <textarea
        id="memo"
        name="memo"
        placeholder="メモ"
        value={form.memo}
        onChange={(e) => setForm({ ...form, memo: e.target.value })}
      />

      <button onClick={submit}>確認へ</button>
    </div>
  );
}
