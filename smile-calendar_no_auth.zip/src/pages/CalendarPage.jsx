// src/pages/CalendarPage.jsx
import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import DayRecord from "../components/DayRecord";
import { getRecord } from "../firebase/reservationApi";

export default function CalendarPage() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [selectedDate, setSelectedDate] = useState(null);
  const [record, setRecord] = useState(null);

  // 日付クリック時の処理
  const handleDateClick = async (dateObj) => {
    const date = dateObj.toISOString().split("T")[0];
    setSelectedDate(date);

    if (currentUser) {
      const data = await getRecord(currentUser.uid, date);
      setRecord(data);
    }
  };

  const handleLogout = () => {
    navigate("/logout");
  };

  return (
    <div style={{ padding: 20 }}>
      <button onClick={handleLogout}>ログアウト</button>
      <h1>カレンダー</h1>

      <Calendar
        onClickDay={handleDateClick}
        locale="ja-JP"
      />

      {selectedDate && (
        <div style={{ marginTop: 40 }}>
          <DayRecord date={selectedDate} initialData={record} />
        </div>
      )}
    </div>
  );
}
