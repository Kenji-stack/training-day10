// src/pages/ReservationConfirmPage.jsx
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { updateRecord } from "../firebase/reservationApi";

const ReservationConfirmPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const reservation = location.state?.reservation;

  if (!reservation) {
    return <p>予約データがありません。</p>;
  }

  const handleConfirm = async () => {
    console.log("保存ボタンがクリックされました");
    console.log("reservation:", reservation);

    const date = reservation.date;
    const data = {
      title: reservation.title,
      memo: reservation.memo,
    };

    console.log("保存するデータ:", { date, data });

    try {
      console.log("updateRecord を呼び出します...");
      await updateRecord(date, data);
      console.log("updateRecord が成功しました");
    } catch (error) {
      console.error("予約保存エラー:", error);
      alert("保存に失敗しました。");
      return; // エラー時は遷移しない
    }

    // 成功時は必ず遷移
    alert("予約を保存しました！");
    console.log("カレンダーページに遷移します");
    navigate("/");
  };

  return (
    <div>
      <h2>予約確認</h2>

      <p>日付: {reservation.date}</p>
      <p>タイトル: {reservation.title}</p>
      <p>メモ: {reservation.memo}</p>

      <button onClick={handleConfirm}>保存する</button>
      <button onClick={() => navigate(-1)}>戻る</button>
    </div>
  );
};

export default ReservationConfirmPage;
