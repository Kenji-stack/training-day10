// src/components/ReservationForm.jsx
import React, { useState, useEffect } from "react";
import { getRecord, updateRecord, deleteRecord } from "../firebase/reservationApi";

export default function ReservationForm({ selectedDate }) {
  const [loading, setLoading] = useState(true);
  const [record, setRecord] = useState({
    morning: false,
    noon: false,
    night: false,
    mouthwash: false,
    floss: false,
    memo: "",
  });

  // ---------------------------
  //  日付変更時に初期データを読み込む
  // ---------------------------
  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      const data = await getRecord(selectedDate);

      if (data) {
        setRecord(data);
      } else {
        setRecord({
          morning: false,
          noon: false,
          night: false,
          mouthwash: false,
          floss: false,
          memo: "",
        });
      }
      setLoading(false);
    };

    fetch();
  }, [selectedDate]);

  // ---------------------------
  //   入力変更
  // ---------------------------
  const handleChange = (key, value) => {
    setRecord((prev) => ({ ...prev, [key]: value }));
  };

  // ---------------------------
  //   保存処理（Firestoreへ）
  // ---------------------------
  const handleSave = async () => {
    setLoading(true);
    await updateRecord(selectedDate, record);
    alert("保存しました！");
    setLoading(false);
  };

  // ---------------------------
  //   削除（Firestore）
  // ---------------------------
  const handleDelete = async () => {
    const ok = window.confirm("削除しますか？");
    if (!ok) return;

    setLoading(true);
    await deleteRecord(selectedDate);
    alert("削除しました！");
    setRecord({
      morning: false,
      noon: false,
      night: false,
      mouthwash: false,
      floss: false,
      memo: "",
    });
    setLoading(false);
  };

  if (loading) return <p>読み込み中…</p>;

  return (
    <div>
      <h2>{selectedDate}</h2>

      <label>
        <input
          type="checkbox"
          checked={record.morning}
          onChange={(e) => handleChange("morning", e.target.checked)}
        />
        朝の歯みがき
      </label>

      <label>
        <input
          type="checkbox"
          checked={record.noon}
          onChange={(e) => handleChange("noon", e.target.checked)}
        />
        昼の歯みがき
      </label>

      <label>
        <input
          type="checkbox"
          checked={record.night}
          onChange={(e) => handleChange("night", e.target.checked)}
        />
        夜の歯みがき
      </label>

      <label>
        <input
          type="checkbox"
          checked={record.mouthwash}
          onChange={(e) => handleChange("mouthwash", e.target.checked)}
        />
        マウスウォッシュ
      </label>

      <label>
        <input
          type="checkbox"
          checked={record.floss}
          onChange={(e) => handleChange("floss", e.target.checked)}
        />
        フロス
      </label>

      <textarea
        value={record.memo}
        onChange={(e) => handleChange("memo", e.target.value)}
        placeholder="通院予約・通院記録・メモ"
        rows={5}
        style={{ width: "300px" }}
      />

      <div style={{ marginTop: "16px" }}>
        <button onClick={handleSave}>保存</button>
        <button onClick={handleDelete} style={{ marginLeft: "8px" }}>
          削除
        </button>
      </div>
    </div>
  );
}
