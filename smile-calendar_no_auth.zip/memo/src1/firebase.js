// src/firebase.js
import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut
} from "firebase/auth";
import {
  getFirestore
} from "firebase/firestore";

// 🔥 Firebase コンソールの値を貼り付け（重要）
const firebaseConfig = {
  apiKey: "AIzaSyA6rUa3g_PDfSfvEdHWfXfFteUDRTXRRKI",
  authDomain: "smile-calendar-system.firebaseapp.com",
  projectId: "smile-calendar-system",
  storageBucket: "smile-calendar-system.firebasestorage.app",
  messagingSenderId: "342941021422",
  appId: "1:342941021422:web:00323a295f077cde65afff",
};

const app = initializeApp(firebaseConfig);

// 🔥 認証
export const auth = getAuth(app);

// 🔥 Firestore
export const db = getFirestore(app);

// 🔥 認証関数をそのまま export
export {
  signInWithEmailAndPassword,
  signOut
};
