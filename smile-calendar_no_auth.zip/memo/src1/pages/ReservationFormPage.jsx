import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ReservationFormPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    date: "",
    title: "",
    memo: "",
  });

  const submit = () => {
    navigate("/reservation/confirm", { state: form });
  };

  return (
    <div>
      <h2>予約登録</h2>

      <input
        type="date"
        value={form.date}
        onChange={(e) => setForm({ ...form, date: e.target.value })}
      />

      <input
        type="text"
        placeholder="タイトル"
        value={form.title}
        onChange={(e) => setForm({ ...form, title: e.target.value })}
      />

      <textarea
        placeholder="メモ"
        value={form.memo}
        onChange={(e) => setForm({ ...form, memo: e.target.value })}
      />

      <button onClick={submit}>確認へ</button>
    </div>
  );
}
