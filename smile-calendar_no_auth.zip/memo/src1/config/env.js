export const SAVE_MODE = "local";
