const functions = require("firebase-functions");
const admin = require("firebase-admin");
const express = require("express");
const cors = require("cors");

// Firebase Admin 初期化
admin.initializeApp();
const db = admin.firestore();

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());


// ----------------------------------------------------------
// ① 予約登録 API（POST /addReservation）
// ----------------------------------------------------------
app.post("/addReservation", async (req, res) => {
  try {
    const data = req.body;

    if (!data || !data.userId || !data.date || !data.time) {
      return res.status(400).json({ error: "Missing fields" });
    }

    const docRef = await db.collection("reservations").add({
      ...data,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return res.json({ success: true, id: docRef.id });
  } catch (e) {
    console.error("Error saving reservation:", e);
    return res.status(500).json({ error: "Failed to add reservation" });
  }
});


// ----------------------------------------------------------
// ② 予約取得 API（GET /getReservations）
// ----------------------------------------------------------
app.get("/getReservations", async (req, res) => {
  try {
    const snapshot = await db
      .collection("reservations")
      .orderBy("createdAt", "desc")
      .get();

    const list = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    return res.json({ reservations: list });
  } catch (e) {
    console.error("Error fetching reservations:", e);
    return res.status(500).json({ error: "Failed to fetch reservations" });
  }
});


// ----------------------------------------------------------
// ③ 認証 API（Firebase Auth の login / logout）
// ----------------------------------------------------------

// ログイン（Email & Password）
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Missing email or password" });
    }

    // Firebase Auth（Client SDK）ではログインできるが、
    // Admin SDK では password の検証ができない。
    // よって、この API は ID トークン検証のみを実装する。
    //
    // ※ログインはフロント側で
    //   signInWithEmailAndPassword(email, password)
    //   を使用する必要がある。
    //

    return res.json({
      message:
        "ログインはフロント側の Firebase Auth（signInWithEmailAndPassword）で行ってください。",
    });
  } catch (e) {
    console.error("Auth error:", e);
    return res.status(500).json({ error: "Login error" });
  }
});

// ログアウト処理
app.post("/logout", async (req, res) => {
  // ※ログアウトもフロント側で行うため、サーバ側はメッセージのみ
  return res.json({ message: "ログアウトはクライアント側で実行してください。" });
});


// ----------------------------------------------------------
// Firebase Functions へ export
// ----------------------------------------------------------
exports.api = functions.region("asia-northeast1").https.onRequest(app);
