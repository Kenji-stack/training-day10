const functions = require("firebase-functions");
const admin = require("firebase-admin");
const express = require("express");
const cors = require("cors");

// Firebase Admin 初期化
admin.initializeApp();
const db = admin.firestore();

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

// ----------------------------------------------------------
// ① 予約登録 API（POST /addReservation）
// ----------------------------------------------------------
app.post("/addReservation", async (req, res) => {
  try {
    const data = req.body;

    if (!data || !data.userId || !data.date || !data.time) {
      return res.status(400).json({ error: "Missing fields" });
    }

    const docRef = await db.collection("reservations").add({
      ...data,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return res.json({ success: true, id: docRef.id });
  } catch (e) {
    console.error("Error saving reservation:", e);
    return res.status(500).json({ error: "Failed to add reservation" });
  }
});

// ----------------------------------------------------------
// ② 予約取得 API（GET /getReservations）
// ----------------------------------------------------------
app.get("/getReservations", async (req, res) => {
  try {
    const snapshot = await db
      .collection("reservations")
      .orderBy("createdAt", "desc")
      .get();

    const list = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    return res.json({ reservations: list });
  } catch (e) {
    console.error("Error fetching reservations:", e);
    return res.status(500).json({ error: "Failed to fetch reservations" });
  }
});

// ----------------------------------------------------------
// ③ 認証 API（Firebase Auth の login / logout）
// ----------------------------------------------------------
app.post("/login", async (req, res) => {
  return res.json({
    message:
      "ログインはフロント側の Firebase Auth（signInWithEmailAndPassword）で行ってください。",
  });
});

app.post("/logout", async (req, res) => {
  return res.json({ message: "ログアウトはクライアント側で実行してください。" });
});

// ----------------------------------------------------------
// Firebase Functions 低料金設定 ＋ 東京リージョン
// ----------------------------------------------------------
exports.api = functions
  .region("asia-northeast1")
  .runWith({
    memory: "128MB",      // 最小メモリ
    timeoutSeconds: 10,   // 長時間実行防止
    minInstances: 0,      // 課金ゼロの鍵（待機中は課金されない）
  })
  .https.onRequest(app);
